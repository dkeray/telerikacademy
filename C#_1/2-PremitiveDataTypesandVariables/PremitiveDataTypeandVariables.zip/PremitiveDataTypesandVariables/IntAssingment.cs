﻿using System;

namespace IntAssingment
{
    class IntAssingment
    {
        static void Main()
        {
            ushort a = 52130;
            sbyte b = -115;
            uint c = 4825932;
            byte d = 97;
            int e = -10000;
            Console.WriteLine("{0} \n {1} \n {2} \n {3} \n {4} \n", a, b, c, d, e);
        }
    }
}