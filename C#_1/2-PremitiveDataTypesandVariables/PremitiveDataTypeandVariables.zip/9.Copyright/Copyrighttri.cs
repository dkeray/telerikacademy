﻿using System;

namespace Copyrighttri
{
    class Program
    {
        static void Main()
        {
            char a = (char)169;
            Console.WriteLine("  " + a);
            Console.WriteLine(" " + a+a+a);
            Console.WriteLine("" +a+a+a+a+a);
        }
    }
}