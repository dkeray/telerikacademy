﻿using System;

namespace IntVar254
{
    class IntVar254
    {
        static void Main()
        {
            byte a = 254;
            string myHex = a.ToString("X"); 
            Console.WriteLine("myHex);
        }
    }
}