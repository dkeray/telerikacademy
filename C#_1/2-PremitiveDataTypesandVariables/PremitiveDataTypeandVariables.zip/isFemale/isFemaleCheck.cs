﻿using System;

namespace isFemale
{
    class isFemaleCheck
    {
        static void Main()
        {
            bool isFemale = false;
            Console.WriteLine(isFemale);
        }
    }
}