﻿using System;

namespace FloatAssigment
{
    class FloatAssigment
    {
        static void Main()
        {
            double a = 34.567839023;
            float b = 12.345f;
            double c = 8923.1234857;
            float d = 3456.091f;
            Console.WriteLine("{0} \n {1} \n {2} \n {3} \n", a, b, c, d);
        }
    }
}