﻿using System;
namespace IntToChar
{
    class IntToChar
    {
        static void Main()
        {
            byte a = 72;
            Console.WriteLine((char)a);
        }
    }
}